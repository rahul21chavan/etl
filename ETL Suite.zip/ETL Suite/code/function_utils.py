# Add helper functions here if needed for code reuse
# For now, not used in the above code, but available for future expansion