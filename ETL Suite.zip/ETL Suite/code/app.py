import streamlit as st
from analyzer import sql_complexity_analyzer
from converter import sql_converter
from optimizer import sql_optimizer
from etl_analyzer import etl_complexity_analyzer
from converter import etl_migration

st.set_page_config(page_title="SQL & ETL Migration Suite", layout="wide")
st.title("🚀 SQL & ETL Migration Suite")

modules = [
    "📊 SQL Complexity Analyzer",
    "🔄 SQL Conversion",
    "⚡ SQL Optimizer",
    "📈 ETL Complexity Analyzer",
    "🔧 ETL Migration"
]
module = st.sidebar.radio("Select Module", modules)

if module == "📊 SQL Complexity Analyzer":
    sql_complexity_analyzer()
elif module == "🔄 SQL Conversion":
    sql_converter()
elif module == "⚡ SQL Optimizer":
    sql_optimizer()
elif module == "📈 ETL Complexity Analyzer":
    etl_complexity_analyzer()
elif module == "🔧 ETL Migration":
    etl_migration()