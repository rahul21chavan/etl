import streamlit as st
import zipfile
import os
import tempfile
import pandas as pd
from io import BytesIO
from function_utils import use_azure_openai, azure_openai_call

def analyze_sql_file(sql_text, dialect):
    """
    Analyze SQL file for object type, complexity, and estimated migration hours.
    Uses Azure OpenAI if enabled, otherwise uses mock logic.
    """
    if use_azure_openai():
        prompt = f"""
        Analyze the following SQL script for:
        - Object type (e.g., PROCEDURE, VIEW)
        - Complexity (SIMPLE, MEDIUM, COMPLEX)
        - Estimated migration hours (integer)
        SQL ({dialect}):
        {sql_text}
        Respond in JSON: {{'object_type':..., 'complexity':..., 'migration_hours':...}}
        """
        try:
            import json
            result = azure_openai_call(prompt, system_prompt="You are a SQL migration expert.")
            return json.loads(result)
        except Exception as e:
            st.error(f"Azure OpenAI API error: {e}")
            # fallback to mock
    # Placeholder for AI-based complexity analysis logic
    # Replace with actual LLM call
    import random
    obj_type = "PROCEDURE" if "proc" in sql_text.lower() else "VIEW"
    complexity = random.choice(["SIMPLE", "MEDIUM", "COMPLEX"])
    est_time = random.randint(1, 8)
    return {
        "object_type": obj_type,
        "complexity": complexity,
        "migration_hours": est_time
    }

def extract_zip(uploaded_file):
    """
    Extract .sql files from uploaded ZIP. Returns list of file paths.
    """
    temp_dir = tempfile.mkdtemp()
    try:
        with zipfile.ZipFile(uploaded_file, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
    except zipfile.BadZipFile:
        st.error("Uploaded file is not a valid ZIP archive.")
        return []
    sql_files = []
    for root, dirs, files in os.walk(temp_dir):
        for file in files:
            if file.endswith(".sql"):
                sql_files.append(os.path.join(root, file))
    return sql_files

def sql_complexity_analyzer():
    """
    Streamlit UI for SQL Complexity Analyzer module with enhanced aesthetics.
    """
    st.markdown("""
        <style>
        .main {background-color: #f8fafc;}
        .stButton>button {background-color: #2563eb; color: white; font-weight: bold; border-radius: 8px;}
        .stDataFrame {background-color: #fff; border-radius: 8px;}
        .stProgress > div > div > div > div {background-color: #2563eb;}
        .stAlert {border-radius: 8px;}
        .st-bb {background: #e0e7ef; border-radius: 8px;}
        .stMarkdown {font-size: 1.1rem;}
        </style>
    """, unsafe_allow_html=True)
    st.image("https://via.placeholder.com/900x120/2563eb/ffffff?text=SQL+Complexity+Analyzer", use_column_width=True)
    st.header("📊 SQL Complexity Analyzer")
    st.markdown(
        """
        <div style='background: #e0e7ef; padding: 1em 1.5em; border-radius: 10px; margin-bottom: 1em;'>
        <b>Analyze the complexity and migration effort of your SQL scripts with a beautiful, modern interface.</b>
        </div>
        """, unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Upload <b>ZIP file</b> of SQL scripts", type="zip", help="Only .zip files containing .sql scripts are supported.")
    dialect = st.selectbox("Select Source Database Dialect", ["Teradata", "Oracle", "SQL Server", "SAP HANA"])
    analyze_btn = st.button("🔍 Analyze SQL Scripts", use_container_width=True)
    if analyze_btn:
        if not uploaded_file:
            st.warning("Please upload a ZIP file containing SQL scripts.")
            return
        sql_files = extract_zip(uploaded_file)
        if not sql_files:
            st.warning("No SQL files found in uploaded ZIP.")
            return
        results = []
        progress = st.progress(0, text="Starting analysis...")
        with st.spinner("Analyzing SQL files..."):
            for i, path in enumerate(sql_files):
                try:
                    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                        sql_text = f.read()
                    res = analyze_sql_file(sql_text, dialect)
                    res["file"] = os.path.basename(path)
                    results.append(res)
                except Exception as e:
                    st.error(f"Error reading {os.path.basename(path)}: {e}")
                progress.progress((i+1)/len(sql_files), text=f"Analyzed {i+1} of {len(sql_files)} files...")
        if results:
            df = pd.DataFrame(results)
            st.success(f"Analyzed {len(results)} files.")
            st.markdown("<b>Results Table</b>", unsafe_allow_html=True)
            st.dataframe(df.style.set_properties(**{'background-color': '#f8fafc', 'border-radius': '8px'}), use_container_width=True)
            st.markdown("<b>Object Complexity Breakdown</b>", unsafe_allow_html=True)
            st.bar_chart(
                {lvl: sum(1 for r in results if r['complexity']==lvl) for lvl in ['SIMPLE','MEDIUM','COMPLEX']}
            )
            st.markdown(f"<b>Estimated Total Migration Hours:</b> <span style='color:#2563eb;font-size:1.2em'>{sum(r['migration_hours'] for r in results)}</span>", unsafe_allow_html=True)
            # Download button for results
            csv = df.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="⬇️ Download Results as CSV",
                data=csv,
                file_name="sql_complexity_results.csv",
                mime="text/csv",
                use_container_width=True
            )
        else:
            st.warning("No results to display.")