import streamlit as st
import zipfile
import os
import tempfile
import pandas as pd
from function_utils import use_azure_openai, azure_openai_call

def analyze_etl_file(etl_text, tool):
    """
    Analyze ETL job definition for complexity, object count, and migration hours.
    Uses Azure OpenAI if enabled, otherwise uses mock logic.
    """
    if use_azure_openai():
        prompt = f"""
        Analyze the following ETL job definition (from {tool}) for:
        - Complexity (SIMPLE, MEDIUM, COMPLEX)
        - Object count (integer)
        - Estimated migration hours (integer)
        XML:
        {etl_text}
        Respond in JSON: {{'complexity':..., 'object_count':..., 'migration_hours':...}}
        """
        try:
            import json
            result = azure_openai_call(prompt, system_prompt="You are an ETL migration expert.")
            return json.loads(result)
        except Exception as e:
            st.error(f"Azure OpenAI API error: {e}")
            # fallback to mock
    # Mock logic (replace with your own AI/LLM or business logic for production use)
    import random
    complexity = random.choice(["SIMPLE", "MEDIUM", "COMPLEX"])
    objects = random.randint(1, 6)
    est_time = random.randint(2, 10)
    return {
        "complexity": complexity,
        "object_count": objects,
        "migration_hours": est_time
    }

def extract_zip(uploaded_file):
    """
    Extract .xml files from uploaded ZIP. Returns list of file paths.
    """
    temp_dir = tempfile.mkdtemp()
    try:
        with zipfile.ZipFile(uploaded_file, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
    except zipfile.BadZipFile:
        st.error("Uploaded file is not a valid ZIP archive.")
        return []
    etl_files = []
    for root, dirs, files in os.walk(temp_dir):
        for file in files:
            if file.endswith(".xml"):
                etl_files.append(os.path.join(root, file))
    return etl_files

def etl_complexity_analyzer():
    """
    Streamlit UI for ETL Complexity Analyzer module with enhanced aesthetics.
    """
    st.markdown("""
        <style>
        .main {background-color: #f8fafc;}
        .stButton>button {background-color: #f43f5e; color: white; font-weight: bold; border-radius: 8px;}
        .stDataFrame {background-color: #fff; border-radius: 8px;}
        .stProgress > div > div > div > div {background-color: #f43f5e;}
        .stAlert {border-radius: 8px;}
        .st-bb {background: #fef2f2; border-radius: 8px;}
        .stMarkdown {font-size: 1.1rem;}
        </style>
    """, unsafe_allow_html=True)
    st.image("https://via.placeholder.com/900x120/f43f5e/ffffff?text=ETL+Complexity+Analyzer", use_column_width=True)
    st.header("📈 ETL Complexity Analyzer")
    st.markdown(
        """
        <div style='background: #fef2f2; padding: 1em 1.5em; border-radius: 10px; margin-bottom: 1em;'>
        <b>Analyze the complexity and migration effort of your ETL job definitions with a beautiful, modern interface.</b>
        </div>
        """, unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Upload <b>ZIP file</b> of ETL job definitions (XML)", type="zip", help="Only .zip files containing .xml ETL jobs are supported.")
    tool = st.selectbox("Source ETL Tool", ["Informatica", "Datastage"])
    analyze_btn = st.button("📈 Analyze ETL Jobs", use_container_width=True)
    if analyze_btn:
        if not uploaded_file:
            st.warning("Please upload a ZIP file containing ETL job definitions.")
            return
        etl_files = extract_zip(uploaded_file)
        if not etl_files:
            st.warning("No ETL XML files found in uploaded ZIP.")
            return
        results = []
        preview_data = []
        progress = st.progress(0, text="Starting analysis...")
        with st.spinner("Analyzing ETL jobs..."):
            for i, path in enumerate(etl_files):
                try:
                    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                        etl_text = f.read()
                    res = analyze_etl_file(etl_text, tool)
                    res["file"] = os.path.basename(path)
                    results.append(res)
                    if i < 3:
                        preview_data.append({
                            'File': os.path.basename(path),
                            'Preview': str(res)
                        })
                except Exception as e:
                    st.error(f"Error reading {os.path.basename(path)}: {e}")
                progress.progress((i+1)/len(etl_files), text=f"Analyzed {i+1} of {len(etl_files)} jobs...")
        if results:
            df = pd.DataFrame(results)
            st.success(f"Analyzed {len(results)} ETL jobs.")
            st.markdown("<b>Results Table</b>", unsafe_allow_html=True)
            st.dataframe(df.style.set_properties(**{'background-color': '#f8fafc', 'border-radius': '8px'}), use_container_width=True)
            st.markdown("<b>Object Complexity Breakdown</b>", unsafe_allow_html=True)
            st.bar_chart(
                {lvl: sum(1 for r in results if r['complexity']==lvl) for lvl in ['SIMPLE','MEDIUM','COMPLEX']}
            )
            st.markdown(f"<b>Estimated Total Migration Hours:</b> <span style='color:#f43f5e;font-size:1.2em'>{sum(r['migration_hours'] for r in results)}</span>", unsafe_allow_html=True)
            if preview_data:
                st.write("**Preview of ETL Analysis Results:**")
                st.dataframe(pd.DataFrame(preview_data).style.set_properties(**{'background-color': '#f8fafc', 'border-radius': '8px'}), use_container_width=True)
            csv = df.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="⬇️ Download Results as CSV",
                data=csv,
                file_name="etl_complexity_results.csv",
                mime="text/csv",
                use_container_width=True
            )
        else:
            st.warning("No results to display.")