import streamlit as st
import zipfile
import os
import tempfile
import pandas as pd
from function_utils import use_azure_openai, azure_openai_call

def optimize_sql_code(sql_text, platform):
    """
    Optimize SQL code for the target platform.
    Uses Azure OpenAI if enabled, otherwise uses mock logic.
    """
    if use_azure_openai():
        prompt = f"Optimize the following SQL for best performance on {platform}. Only output the optimized SQL.\nSQL:\n{sql_text}"
        try:
            return azure_openai_call(prompt, system_prompt="You are a SQL optimization expert.")
        except Exception as e:
            st.error(f"Azure OpenAI API error: {e}")
            # fallback to mock
    # Replace with AI/LLM call for actual optimization
    return f"-- Optimized for {platform}:\n" + sql_text

def extract_zip(uploaded_file):
    """
    Extract .sql files from uploaded ZIP. Returns list of file paths and temp dir.
    """
    temp_dir = tempfile.mkdtemp()
    try:
        with zipfile.ZipFile(uploaded_file, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
    except zipfile.BadZipFile:
        st.error("Uploaded file is not a valid ZIP archive.")
        return [], temp_dir
    files = []
    for root, dirs, filez in os.walk(temp_dir):
        for file in filez:
            if file.endswith(".sql"):
                files.append(os.path.join(root, file))
    return files, temp_dir

def sql_optimizer():
    """
    Streamlit UI for SQL Optimizer module with enhanced aesthetics.
    """
    st.markdown("""
        <style>
        .main {background-color: #f8fafc;}
        .stButton>button {background-color: #7c3aed; color: white; font-weight: bold; border-radius: 8px;}
        .stDataFrame {background-color: #fff; border-radius: 8px;}
        .stProgress > div > div > div > div {background-color: #7c3aed;}
        .stAlert {border-radius: 8px;}
        .st-bb {background: #ede9fe; border-radius: 8px;}
        .stMarkdown {font-size: 1.1rem;}
        </style>
    """, unsafe_allow_html=True)
    st.image("https://via.placeholder.com/900x120/7c3aed/ffffff?text=SQL+Optimizer", use_column_width=True)
    st.header("⚡ SQL Optimizer")
    st.markdown(
        """
        <div style='background: #ede9fe; padding: 1em 1.5em; border-radius: 10px; margin-bottom: 1em;'>
        <b>Optimize SQL scripts for cloud data platforms with a beautiful, modern interface.</b>
        </div>
        """, unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Upload <b>ZIP file</b> of SQL scripts", type="zip", help="Only .zip files containing .sql scripts are supported.")
    platform = st.selectbox("Target Platform", ["Databricks", "BigQuery", "Snowflake"])
    optimize_btn = st.button("⚡ Optimize SQL Scripts", use_container_width=True)
    if optimize_btn:
        if not uploaded_file:
            st.warning("Please upload a ZIP file containing SQL scripts.")
            return
        sql_files, temp_dir = extract_zip(uploaded_file)
        if not sql_files:
            st.warning("No SQL files found in uploaded ZIP.")
            return
        output_dir = tempfile.mkdtemp()
        result_files = []
        preview_data = []
        progress = st.progress(0, text="Starting optimization...")
        with st.spinner("Optimizing SQL files..."):
            for i, in_file in enumerate(sql_files):
                try:
                    with open(in_file, 'r', encoding='utf-8', errors='ignore') as f:
                        text = f.read()
                    out_text = optimize_sql_code(text, platform)
                    out_file = os.path.join(output_dir, os.path.basename(in_file))
                    with open(out_file, 'w', encoding='utf-8') as f:
                        f.write(out_text)
                    result_files.append(out_file)
                    if i < 3:
                        preview_data.append({
                            'File': os.path.basename(in_file),
                            'Preview': out_text[:500] + ("..." if len(out_text) > 500 else "")
                        })
                except Exception as e:
                    st.error(f"Error optimizing {os.path.basename(in_file)}: {e}")
                progress.progress((i+1)/len(sql_files), text=f"Optimized {i+1} of {len(sql_files)} files...")
        # Create ZIP for download
        zip_path = os.path.join(output_dir, "optimized_sql.zip")
        with zipfile.ZipFile(zip_path, 'w') as zipf:
            for file in result_files:
                zipf.write(file, os.path.basename(file))
        st.success(f"Optimized {len(result_files)} files.")
        if preview_data:
            st.write("**Preview of Optimized Files:**")
            st.dataframe(pd.DataFrame(preview_data).style.set_properties(**{'background-color': '#f8fafc', 'border-radius': '8px'}), use_container_width=True)
        with open(zip_path, "rb") as f:
            st.download_button("⬇️ Download Optimized ZIP", f, file_name="optimized_sql.zip", use_container_width=True)