import os
import openai

# Add helper functions here if needed for code reuse
# For now, not used in the above code, but available for future expansion

def use_azure_openai():
    """
    Returns True if Azure OpenAI API should be used (based on env or Streamlit toggle).
    """
    import streamlit as st
    return st.session_state.get('use_azure_openai', False) or os.getenv('USE_AZURE_OPENAI', '0') == '1'

def azure_openai_call(prompt, system_prompt=None, temperature=0.2, max_tokens=512):
    """
    Calls Azure OpenAI API with the given prompt. Returns the response text.
    """
    api_key = os.getenv('AZURE_OPENAI_API_KEY')
    endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')
    deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT')
    if not (api_key and endpoint and deployment):
        raise RuntimeError("Azure OpenAI API credentials are not set.")
    openai.api_type = "azure"
    openai.api_key = api_key
    openai.api_base = endpoint
    openai.api_version = "2023-05-15"
    messages = []
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    messages.append({"role": "user", "content": prompt})
    response = openai.ChatCompletion.create(
        engine=deployment,
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens
    )
    return response.choices[0].message['content']

def app_sidebar():
    import streamlit as st
    st.sidebar.markdown("""
        <div style='padding:0.5em 0 1em 0;border-bottom:1px solid #eee;'>
        <b>⚙️ Settings</b>
        </div>
    """, unsafe_allow_html=True)
    use_ai = st.sidebar.toggle("Use Azure OpenAI API", value=False, help="Enable to use Azure OpenAI for analysis, conversion, and optimization.")
    st.session_state['use_azure_openai'] = use_ai