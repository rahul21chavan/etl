import streamlit as st
import zipfile
import os
import tempfile
import pandas as pd
from io import BytesIO
from function_utils import use_azure_openai, azure_openai_call

def convert_sql_code(sql_text, src, tgt):
    """
    Convert SQL code from source to target dialect.
    Uses Azure OpenAI if enabled, otherwise uses mock logic.
    """
    if use_azure_openai():
        prompt = f"Convert the following SQL from {src} to {tgt} dialect. Only output the converted SQL.\nSQL:\n{sql_text}"
        try:
            return azure_openai_call(prompt, system_prompt="You are a SQL conversion expert.")
        except Exception as e:
            st.error(f"Azure OpenAI API error: {e}")
            # fallback to mock
    return f"-- Converted from {src} to {tgt}:\n" + sql_text.replace(src.lower(), tgt.lower())

def extract_zip(uploaded_file, file_ext=".sql"):
    """
    Extract files with given extension from uploaded ZIP. Returns list of file paths and temp dir.
    """
    temp_dir = tempfile.mkdtemp()
    try:
        with zipfile.ZipFile(uploaded_file, 'r') as zip_ref:
            zip_ref.extractall(temp_dir)
    except zipfile.BadZipFile:
        st.error("Uploaded file is not a valid ZIP archive.")
        return [], temp_dir
    files = []
    for root, dirs, fs in os.walk(temp_dir):
        for file in fs:
            if file.endswith(file_ext):
                files.append(os.path.join(root, file))
    return files, temp_dir

def sql_converter():
    """
    Streamlit UI for SQL Converter module with enhanced aesthetics.
    """
    st.markdown("""
        <style>
        .main {background-color: #f8fafc;}
        .stButton>button {background-color: #059669; color: white; font-weight: bold; border-radius: 8px;}
        .stDataFrame {background-color: #fff; border-radius: 8px;}
        .stProgress > div > div > div > div {background-color: #059669;}
        .stAlert {border-radius: 8px;}
        .st-bb {background: #e0f2f1; border-radius: 8px;}
        .stMarkdown {font-size: 1.1rem;}
        </style>
    """, unsafe_allow_html=True)
    st.image("https://via.placeholder.com/900x120/059669/ffffff?text=SQL+Converter", use_column_width=True)
    st.header("🔄 SQL Conversion")
    st.markdown(
        """
        <div style='background: #e0f2f1; padding: 1em 1.5em; border-radius: 10px; margin-bottom: 1em;'>
        <b>Convert SQL scripts between major database dialects with a beautiful, modern interface.</b>
        </div>
        """, unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Upload <b>ZIP file</b> of SQL scripts", type="zip", help="Only .zip files containing .sql scripts are supported.")
    src = st.selectbox("Source Database Dialect", ["Teradata", "Oracle", "SQL Server", "SAP HANA"])
    tgt = st.selectbox("Target Database Dialect", ["Databricks", "BigQuery", "Snowflake"])
    convert_btn = st.button("🔄 Convert SQL Scripts", use_container_width=True)
    if convert_btn:
        if not uploaded_file:
            st.warning("Please upload a ZIP file containing SQL scripts.")
            return
        sql_files, temp_dir = extract_zip(uploaded_file)
        if not sql_files:
            st.warning("No SQL files found in uploaded ZIP.")
            return
        output_dir = tempfile.mkdtemp()
        result_files = []
        preview_data = []
        progress = st.progress(0, text="Starting conversion...")
        with st.spinner("Converting SQL files..."):
            for i, in_file in enumerate(sql_files):
                try:
                    with open(in_file, 'r', encoding='utf-8', errors='ignore') as f:
                        text = f.read()
                    out_text = convert_sql_code(text, src, tgt)
                    out_file = os.path.join(output_dir, os.path.basename(in_file))
                    with open(out_file, 'w', encoding='utf-8') as f:
                        f.write(out_text)
                    result_files.append(out_file)
                    if i < 3:  # Preview first 3 conversions
                        preview_data.append({
                            'File': os.path.basename(in_file),
                            'Preview': out_text[:500] + ("..." if len(out_text) > 500 else "")
                        })
                except Exception as e:
                    st.error(f"Error converting {os.path.basename(in_file)}: {e}")
                progress.progress((i+1)/len(sql_files), text=f"Converted {i+1} of {len(sql_files)} files...")
        # Create ZIP for download
        zip_path = os.path.join(output_dir, "converted_sql.zip")
        with zipfile.ZipFile(zip_path, 'w') as zipf:
            for file in result_files:
                zipf.write(file, os.path.basename(file))
        st.success(f"Converted {len(result_files)} files.")
        if preview_data:
            st.write("**Preview of Converted Files:**")
            st.dataframe(pd.DataFrame(preview_data).style.set_properties(**{'background-color': '#f8fafc', 'border-radius': '8px'}), use_container_width=True)
        with open(zip_path, "rb") as f:
            st.download_button("⬇️ Download Converted ZIP", f, file_name="converted_sql.zip", use_container_width=True)

def etl_migration():
    """
    Streamlit UI for ETL Migration module with enhanced aesthetics.
    """
    st.markdown("""
        <style>
        .main {background-color: #f8fafc;}
        .stButton>button {background-color: #f59e42; color: white; font-weight: bold; border-radius: 8px;}
        .stDataFrame {background-color: #fff; border-radius: 8px;}
        .stProgress > div > div > div > div {background-color: #f59e42;}
        .stAlert {border-radius: 8px;}
        .st-bb {background: #fff7ed; border-radius: 8px;}
        .stMarkdown {font-size: 1.1rem;}
        </style>
    """, unsafe_allow_html=True)
    st.image("https://via.placeholder.com/900x120/f59e42/ffffff?text=ETL+Migration", use_column_width=True)
    st.header("🔧 ETL Migration")
    st.markdown(
        """
        <div style='background: #fff7ed; padding: 1em 1.5em; border-radius: 10px; margin-bottom: 1em;'>
        <b>Migrate ETL job definitions between platforms with a beautiful, modern interface.</b>
        </div>
        """, unsafe_allow_html=True)
    uploaded_file = st.file_uploader("Upload <b>ZIP</b> of ETL job definitions (XML)", type="zip", help="Only .zip files containing .xml ETL jobs are supported.")
    src = st.selectbox("Source ETL Tool", ["Informatica", "Datastage", "Snowflake SQL"])
    tgt = st.selectbox("Target Framework", ["Snowpark PySpark", "Snowflake SQL", "Matillion", "DBT"])
    output_type = st.selectbox("Output File Type", [".sql", ".py", ".yaml", ".json"])
    custom_prompt = st.text_area("AI Migration Prompt (editable)", 
        f"Convert this {src} ETL job to {tgt} in {output_type} format.")
    migrate_btn = st.button("🔧 Migrate ETL Jobs", use_container_width=True)
    if migrate_btn:
        if not uploaded_file:
            st.warning("Please upload a ZIP file containing ETL job definitions.")
            return
        etl_files, temp_dir = extract_zip(uploaded_file, ".xml")
        if not etl_files:
            st.warning("No XML files found in uploaded ZIP.")
            return
        output_dir = tempfile.mkdtemp()
        result_files = []
        preview_data = []
        progress = st.progress(0, text="Starting migration...")
        with st.spinner("Migrating ETL jobs..."):
            for i, in_file in enumerate(etl_files):
                try:
                    with open(in_file, 'r', encoding='utf-8', errors='ignore') as f:
                        text = f.read()
                    # Mock migration logic
                    out_text = f"# Converted {os.path.basename(in_file)} from {src} to {tgt}\n# Output format: {output_type}\n# Prompt: {custom_prompt}\n" + text
                    out_file = os.path.join(output_dir, os.path.splitext(os.path.basename(in_file))[0] + output_type)
                    with open(out_file, 'w', encoding='utf-8') as f:
                        f.write(out_text)
                    result_files.append(out_file)
                    if i < 3:
                        preview_data.append({
                            'File': os.path.basename(in_file),
                            'Preview': out_text[:500] + ("..." if len(out_text) > 500 else "")
                        })
                except Exception as e:
                    st.error(f"Error migrating {os.path.basename(in_file)}: {e}")
                progress.progress((i+1)/len(etl_files), text=f"Migrated {i+1} of {len(etl_files)} jobs...")
        # Create ZIP for download
        zip_path = os.path.join(output_dir, "migrated_etl.zip")
        with zipfile.ZipFile(zip_path, 'w') as zipf:
            for file in result_files:
                zipf.write(file, os.path.basename(file))
        st.success(f"Migrated {len(result_files)} ETL jobs.")
        if preview_data:
            st.write("**Preview of Migrated Files:**")
            st.dataframe(pd.DataFrame(preview_data).style.set_properties(**{'background-color': '#f8fafc', 'border-radius': '8px'}), use_container_width=True)
        with open(zip_path, "rb") as f:
            st.download_button("⬇️ Download Migrated ZIP", f, file_name="migrated_etl.zip", use_container_width=True)