# ETL Suite

![ETL Suite Banner](https://via.placeholder.com/900x200?text=ETL+Suite)

A powerful, modular Python suite for Extract, Transform, Load (ETL) operations, SQL/ETL analysis, conversion, and optimization. ETL Suite provides a user-friendly web interface to help data engineers and analysts process, analyze, and migrate data pipelines efficiently.

---

## Features
- **Interactive Web UI**: Built with Streamlit for easy, no-code operation.
- **SQL Complexity Analyzer**: Upload SQL scripts (ZIP), select your database dialect, and get instant complexity and migration effort estimates.
- **SQL Converter**: Convert SQL scripts between major database dialects (Teradata, Oracle, SQL Server, SAP HANA → Databricks, BigQuery, Snowflake).
- **SQL Optimizer**: Optimize SQL scripts for cloud data platforms with a single click.
- **ETL Complexity Analyzer**: Analyze Informatica/Datastage ETL job definitions (XML) for complexity and migration effort.
- **ETL Migration**: (Planned) Migrate ETL jobs between platforms (coming soon).
- **Batch Processing**: Upload ZIP files containing multiple scripts/jobs for bulk analysis and conversion.
- **Extensible**: Easily add new modules for custom ETL or SQL tasks.

---

## Project Structure
```
code/
    analyzer.py         # SQL analysis tools
    app.py              # Streamlit web application
    converter.py        # SQL conversion utilities
    etl_analyzer.py     # ETL process analyzer
    function_utils.py   # Utility functions
    optimizer.py        # SQL optimization tools
    requirements.txt    # Python dependencies
inputs/                 # Input data files
outputs/                # Output data files
```

---

## Getting Started

### Prerequisites
- Python 3.8+
- pip (Python package manager)

### Installation
1. Clone the repository or download the source code.
2. Install dependencies:
   ```powershell
   pip install -r code/requirements.txt
   ```

### Running the App
Start the Streamlit web interface:
```powershell
streamlit run code/app.py
```

---

## Usage

1. **Upload** your SQL or ETL job files as ZIP archives via the web interface.
2. **Select** the desired module from the sidebar:
   - SQL Complexity Analyzer
   - SQL Conversion
   - SQL Optimizer
   - ETL Complexity Analyzer
   - ETL Migration (coming soon)
3. **Configure** options (source/target dialect, platform, etc.).
4. **Run** the analysis/conversion/optimization and download results.

> **Tip:** Outputs are saved in the `outputs/` directory and available for download in the UI.

---

## Example Screenshots

> _Replace these with your own screenshots_

![UI Screenshot](https://via.placeholder.com/800x400?text=Streamlit+App+Screenshot)

---

## FAQ

**Q: What file formats are supported?**
- SQL scripts (`.sql`) and ETL job definitions (`.xml`) in ZIP archives.

**Q: Can I add my own modules?**
- Yes! Add a new Python file in `code/` and register it in `app.py`.

**Q: Is this production-ready?**
- This is a template and demo. Replace placeholder logic with your own AI/LLM or business logic for production use.

---

## Troubleshooting
- If Streamlit does not launch, ensure all dependencies are installed and you are using Python 3.8+.
- For large ZIP files, processing may take longer.
- Check the terminal for error messages if something fails.

---

## Contributing
Contributions are welcome! Please fork the repository and submit a pull request. For major changes, open an issue first to discuss your ideas.

1. Fork the repo
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## Contact & Acknowledgments
- **Author:** [Your Name or Organization]
- **Email:** [your.email@example.com]
- **License:** MIT License

Special thanks to the open-source community and contributors!

---
